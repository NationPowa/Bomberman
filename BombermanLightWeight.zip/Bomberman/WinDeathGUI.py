import g2d
import time
import pygame as pg
import requests
from GameSettings import GameSettings
import io

SEC_MULTIPLIER = 0.7
DIST = 0  # Distance of GUI from borders

class WinDeathGUI:
    def __init__(self, outcome):
        self.outcome = outcome  # "WIN" or "DEATH"
        self.settings = GameSettings()
        self.last_switch_time = time.time() * 1000 / SEC_MULTIPLIER
        self.show_alternate = False

        self.images = {
            "WIN": "GUIs/BombermanWin.png",
            "DEATH": "GUIs/BombermanDeath.png",
            "EMPTY_WIN": "GUIs/BombermanWinEmpty.png",
            "EMPTY_DEATH": "GUIs/BombermanDeathEmpty.png"
        }

        # Initialize music
        pg.mixer.init()
        
        # Load win and death sounds from URL
        self.win_sound = self.load_sound("https://raw.githubusercontent.com/NationPowa/Bomberman/main/Bomberman/Soundtracks/levelCompleted.mp3")
        self.death_sound = self.load_sound("https://raw.githubusercontent.com/NationPowa/Bomberman/main/Bomberman/Soundtracks/death.mp3")
        self.win_sound.set_volume(self.settings.VOLUME)
        self.death_sound.set_volume(self.settings.VOLUME)

        self.play_outcome_music()

    def load_sound(self, url):
        """Download and load a sound effect from a URL."""
        sound_data = requests.get(url).content
        sound_file = io.BytesIO(sound_data)
        return pg.mixer.Sound(sound_file)

    def play_outcome_music(self):
        """Play music based on outcome."""
        pg.mixer.stop()
        if not self.settings.MUTE_MUSIC:
            self.stop_all_sounds()
            if self.outcome == "WIN":
                self.win_sound.play()
            elif self.outcome == "DEATH":
                self.death_sound.play()

    def tick(self):
        """Main loop: handles game logic and input."""
        g2d.clear_canvas()
        self.handle_input()
        self.draw_outcome()
        g2d.update_canvas()

    def handle_input(self):
        """Handles user input (e.g., press 'Enter' to restart)."""
        current_time = time.time() * 1000 / SEC_MULTIPLIER  # Current time in milliseconds
        if current_time - self.last_switch_time >= 1000:  # Switch image every second
            self.show_alternate = not self.show_alternate
            self.last_switch_time = current_time

        if g2d.key_pressed("Enter"):
            self.restart_game()

    def draw_outcome(self):
        """Draw the outcome (win or death) on the GUI."""
        if self.outcome == "WIN":
            image_to_draw = self.images["EMPTY_WIN"] if self.show_alternate else self.images["WIN"]
        elif self.outcome == "DEATH":
            image_to_draw = self.images["EMPTY_DEATH"] if self.show_alternate else self.images["DEATH"]
        else:
            return

        self.draw_resized_image(image_to_draw, (0, 0))

    def restart_game(self):
        """Restart the game."""
        from GameBomberman import main as start_game
        pg.mixer.music.stop()

        if not self.settings.MUTE_MUSIC:
            self.play_level_music()
        
        start_game(self.settings)

    def play_level_music(self):
        """Play level music."""
        self.stop_all_sounds()
        level_music_url = "https://raw.githubusercontent.com/NationPowa/Bomberman/main/Bomberman/Soundtracks/levelTheme.mp3"
        self.play_music_from_url(level_music_url)
    
    def play_music_from_url(self, url):
        """Download and play music from the specified URL."""
        music_data = requests.get(url).content
        music_file = io.BytesIO(music_data)
        pg.mixer.music.load(music_file)
        pg.mixer.music.set_volume(self.settings.VOLUME)
        pg.mixer.music.play(-1)

    def stop_all_sounds(self):
        """Stop all music and sound effects."""
        pg.mixer.music.stop()
        pg.mixer.stop()
        pg.mixer.fadeout(500)

    def draw_resized_image(self, image_path, position):
        """Draw a resized image to fit the canvas."""
        canvas_width, canvas_height = g2d.canvas_size()
        
        image = g2d.load_image(image_path)
        
        # Get original image size
        image_surface = g2d._loaded[image]
        original_width, original_height = image_surface.get_size()

        # Calculate scaling factor to maintain proportions
        width_ratio = (canvas_width - 2 * DIST) / original_width
        height_ratio = (canvas_height - 2 * DIST) / original_height
        scale_factor = min(width_ratio, height_ratio)

        new_width = int(original_width * scale_factor)
        new_height = int(original_height * scale_factor)

        # Resize the image
        resized_image = pg.transform.scale(image_surface, (new_width, new_height))
        
        # Center the image
        center_x = max(DIST, (canvas_width - new_width) // 2)
        center_y = max(DIST, (canvas_height - new_height) // 2)

        # Draw the resized image
        g2d._canvas.blit(resized_image, (center_x, center_y))

def main(outcome):
    """Main function to initialize the win or death GUI."""
    g2d.init_canvas((256, 240), scale=3)
    gui = WinDeathGUI(outcome)
    g2d.main_loop(gui.tick)
