import g2d, time
import pygame as pg
import requests
from GameBomberman import main as start_game
from GameSettings import GameSettings
import io

SEC_MULTIPLIER = 0.7
DIST = 0  # Distance of GUI from borders

class GameMenu:
    def __init__(self):
        self.settings = GameSettings()
        self.in_settings = False
        self.selected_option = "START"  # Options: "START" or "SETTINGS"
        self.last_switch_time = time.time() * 1000 / SEC_MULTIPLIER
        self.show_alternate = False
        self.show_message = None  # Temporary message to display
        self.message_time = 0  # Time when the message appeared

        self.images = {
            "START": "GUIs/BombermanTitleStart.png",
            "SETTINGS": "GUIs/BombermanTitleSettings.png",
            "EMPTY": "GUIs/BombermanTitleEmpty.png"
        }

        pg.mixer.init()
        self.music_playing = False

    def tick(self):
        g2d.clear_canvas()
        g2d.set_color((0, 0, 0))
        g2d.draw_rect((0, 0), (g2d.canvas_size()))
        self.handle_navigation()
        self.draw_menu()
        self.draw_message()
        g2d.update_canvas()

        if not self.music_playing and not self.settings.MUTE_MUSIC:
            self.play_music()

    def handle_navigation(self):
        current_time = time.time() * 1000 / SEC_MULTIPLIER  # Current time in milliseconds
        if current_time - self.last_switch_time >= 1000:  # Switch every second
            self.show_alternate = not self.show_alternate
            self.last_switch_time = current_time

        if g2d.key_pressed("ArrowRight"):
            self.selected_option = "SETTINGS"
        elif g2d.key_pressed("ArrowLeft"):
            self.selected_option = "START"

        if g2d.key_pressed("Enter"):
            if self.selected_option == "START":
                self.start_game()
            elif self.selected_option == "SETTINGS":
                self.show_message = "Settings are work in progress (edit GameSettings.py)"
                self.message_time = current_time

    def draw_menu(self):
        image_to_draw = self.images["EMPTY"] if self.show_alternate else self.images[self.selected_option]
        
        self.draw_resized_image(image_to_draw, (0, 0))

        if self.in_settings:
            self.draw_settings()

    def draw_message(self):
        if self.show_message:
            current_time = time.time() * 1000 / SEC_MULTIPLIER
            if current_time - self.message_time < 7000:
                g2d.set_color((0, 0, 0))
                g2d.draw_rect((0, 0), (g2d.canvas_size()))
                g2d.set_color((255, 255, 255))
                g2d.draw_text(self.show_message, (g2d.canvas_size()[0]/2,g2d.canvas_size()[1]/2), 11)
            else:
                self.show_message = None  # Hide message after 7 seconds

    def draw_settings(self):
        pass

    def start_game(self):
        pg.mixer.music.stop()
        
        if not self.settings.MUTE_MUSIC:
            self.play_level_music()
        
        start_game(self.settings)

    def play_music(self):
        music_url = "https://raw.githubusercontent.com/NationPowa/Bomberman/main/Bomberman/Soundtracks/mainMenu.mp3"
        music_data = requests.get(music_url).content
        music_file = io.BytesIO(music_data)
        pg.mixer.music.load(music_file)
        pg.mixer.music.set_volume(self.settings.VOLUME)
        pg.mixer.music.play(-1)
        self.music_playing = True

    def stop_all_sounds(self):
        """Stop all music and sound effects."""
        pg.mixer.music.stop()
        pg.mixer.stop()
        pg.mixer.fadeout(500)

    def play_level_music(self):
        self.stop_all_sounds()
        level_music_url = "https://raw.githubusercontent.com/NationPowa/Bomberman/main/Bomberman/Soundtracks/levelTheme.mp3"
        level_music_data = requests.get(level_music_url).content
        level_music_file = io.BytesIO(level_music_data)
        pg.mixer.music.load(level_music_file)
        pg.mixer.music.set_volume(self.settings.VOLUME)
        pg.mixer.music.play(-1)
    
    def draw_resized_image(self, image_path, position):
        canvas_width, canvas_height = g2d.canvas_size()
        
        image = g2d.load_image(image_path)
        
        # Get the original dimensions of the image
        image_surface = g2d._loaded[image]
        original_width, original_height = image_surface.get_size()

        # Calculate the scale factor to maintain proportions
        width_ratio = (canvas_width - 2 * DIST) / original_width
        height_ratio = (canvas_height - 2 * DIST) / original_height
        scale_factor = min(width_ratio, height_ratio)  # Maintain the proportion

        new_width = int(original_width * scale_factor)
        new_height = int(original_height * scale_factor)

        resized_image = pg.transform.scale(image_surface, (new_width, new_height))
        
        # Calculate the position to center the image, considering the distance from borders
        center_x = max(DIST, (canvas_width - new_width) // 2)
        center_y = max(DIST, (canvas_height - new_height) // 2)

        # Draw the resized image centered with a distance from the border
        g2d._canvas.blit(resized_image, (center_x, center_y))


def main():
    g2d.init_canvas((256, 240), scale=3)
    menu = GameMenu()
    g2d.main_loop(menu.tick)

if __name__ == "__main__":
    main()
